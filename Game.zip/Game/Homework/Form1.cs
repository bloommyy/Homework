﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int points = 0;
        int lives = 3;
        Random rnd = new Random();
        int numMove, numPlay;
        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button1.Visible = false;
            button2.Enabled = false;
            button3.Enabled = false;
            label1.Enabled = false;
            label1.Visible = false;
            label2.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label5.Text = points.ToString();
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox6.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            button4.Enabled = false;
            button5.Enabled = false;
            button5.Visible = false;
            button6.Visible = false;
            button6.Enabled = false;
            numPlay = rnd.Next(5, 11);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            numMove = rnd.Next(8);
        }
        int speed = 15;
        private void timer2_Tick(object sender, EventArgs e)
        {
            label5.Text = points.ToString();
            if (numMove == 0)
            {
                pictureBox4.Top -= speed;
            }
            else if (numMove == 1)
            {
                pictureBox4.Image = Properties.Resources.dogeeee;
                pictureBox4.Top -= speed;
                pictureBox4.Left += speed;
            }
            else if (numMove == 2)
            {
                pictureBox4.Image = Properties.Resources.dogeeee;
                pictureBox4.Left += speed;
            }
            else if (numMove == 3)
            {
                pictureBox4.Image = Properties.Resources.dogeeee;
                pictureBox4.Top += speed;
                pictureBox4.Left += speed;
            }
            else if (numMove == 4)
            {
                pictureBox4.Top += speed;
            }
            else if (numMove == 5)
            {
                pictureBox4.Image = Properties.Resources.dogeeee_2;
                pictureBox4.Top += speed;
                pictureBox4.Left -= speed;
            }
            else if (numMove == 6)
            {
                pictureBox4.Image = Properties.Resources.dogeeee_2;
                pictureBox4.Left -= speed;
            }
            else
            {
                pictureBox4.Image = Properties.Resources.dogeeee_2;
                pictureBox4.Top -= speed;
                pictureBox4.Left -= speed;
            }

            if (pictureBox4.Top < -10)
            {
                pictureBox4.Top = -10;
            }
            if (pictureBox4.Top > 500)
            {
                pictureBox4.Top = 499;
            }

            if (pictureBox4.Left < -28)
            {
                pictureBox4.Left = -28;
            }
            if (pictureBox4.Left > 1151)
            {
                pictureBox4.Left = 1151;
            }

            if (pictureBox5.Top < -10)
            {
                pictureBox5.Top = -10;
            }
            if (pictureBox5.Top > 500)
            {
                pictureBox5.Top = 499;
            }

            if (pictureBox5.Left < -28)
            {
                pictureBox5.Left = -28;
            }
            if (pictureBox5.Left > 1151)
            {
                pictureBox5.Left = 1151;
            }
            if (lives == 0)
            {
                label6.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                label2.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                button3.Enabled = true;
                button3.Visible = true;
                label7.Visible = true;
                label8.Text = points.ToString();
                label8.Visible = true;
                label9.Visible = true;
                pictureBox7.Enabled = false;
                pictureBox7.Visible = false;
                button4.Enabled = true;
                button4.Visible = true;
                label4.Visible = false;
                label5.Visible = false;
            }
            if (points == 1000)
            {
                label10.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                label2.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                button3.Enabled = true;
                button3.Visible = true;
                label7.Visible = true;
                label8.Text = points.ToString();
                label8.Visible = true;
                label9.Visible = true;
                pictureBox7.Enabled = false;
                pictureBox7.Visible = false;
                button4.Enabled = true;
                button4.Visible = true;
                label4.Visible = false;
                label5.Visible = false;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                button3.Top = 387;
                button3.Left = 598;
            }
        }
        int escape = 0;
        private void From1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                pictureBox6.Left += speed;
            }
            if (e.KeyCode == Keys.Left)
            {
                pictureBox6.Left -= speed;
            }
            if (e.KeyCode == Keys.Up)
            {
                pictureBox6.Top -= speed;
            }
            if (e.KeyCode == Keys.Down)
            {
                pictureBox6.Top += speed;
            }

            if (pictureBox6.Top < 0)
            {
                pictureBox6.Top = 0;
            }
            if (pictureBox6.Top > 457)
            {
                pictureBox6.Top = 457;
            }

            if (pictureBox6.Left < 0)
            {
                pictureBox6.Left = 0;
            }
            if (pictureBox6.Left > 1221)
            {
                pictureBox6.Left = 1221;
            }
            if (e.KeyCode == Keys.Escape)
            {
                pictureBox1.Enabled = false;
                pictureBox1.Visible = false;
                pictureBox2.Enabled = false;
                pictureBox2.Visible = false;
                pictureBox3.Enabled = false;
                pictureBox3.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox5.Enabled = false;
                pictureBox5.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                pictureBox7.Visible = false;
                pictureBox7.Enabled = false;
                label2.Visible = false;
                timer1.Enabled = false;
                timer2.Enabled = false;
                button2.Visible = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button3.Visible = true;
                label3.Visible = true;
                timer3.Enabled = false;
                pictureBox7.Visible = false;
                if (escape % 2 != 0)
                {
                    pictureBox4.Enabled = true;
                    pictureBox4.Visible = true;
                    /*pictureBox5.Enabled = true;
                    pictureBox5.Visible = true;*/
                    pictureBox6.Enabled = true;
                    pictureBox6.Visible = true;
                    label2.Visible = true;
                    timer1.Enabled = true;
                    timer2.Enabled = true;
                    button2.Visible = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button3.Visible = false;
                    label3.Visible = false;
                    if (flag != 0)
                    {
                        pictureBox7.Visible = true;   
                    }
                    timer3.Enabled = true;
                    if (lives == 3)
                    {
                        pictureBox1.Enabled = true;
                        pictureBox1.Visible = true;
                        pictureBox2.Enabled = true;
                        pictureBox2.Visible = true;
                        pictureBox3.Enabled = true;
                        pictureBox3.Visible = true;
                    }
                    else if (lives == 2)
                    {
                        pictureBox1.Enabled = true;
                        pictureBox1.Visible = true;
                        pictureBox2.Enabled = true;
                        pictureBox2.Visible = true;
                    }
                    else
                    {
                        pictureBox1.Enabled = true;
                        pictureBox1.Visible = true;
                    }
                }
                escape++;
            }
            for (int i = 0; i < poos1.Count; i++)
            {
                    if (pictureBox6.Bounds.IntersectsWith(poos1[i].Bounds) && e.KeyCode == Keys.Space)
                    {
                        poos1[i].Enabled = false;
                        poos1[i].Visible = false;
                        points += 10;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox4.Enabled = true;
            pictureBox4.Visible = true;
            pictureBox6.Enabled = true;
            pictureBox6.Visible = true;
            label2.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            button2.Visible = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button3.Visible = false;
            label3.Visible = false;
            if (flag != 0)
            {
                pictureBox7.Visible = true;
            }
            timer3.Enabled = true;
            escape++;
            if (lives == 3)
            {
                pictureBox1.Enabled = true;
                pictureBox1.Visible = true;
                pictureBox2.Enabled = true;
                pictureBox2.Visible = true;
                pictureBox3.Enabled = true;
                pictureBox3.Visible = true;
            }
            else if (lives == 2)
            {
                pictureBox1.Enabled = true;
                pictureBox1.Visible = true;
                pictureBox2.Enabled = true;
                pictureBox2.Visible = true;
            }
            else
            {
                pictureBox1.Enabled = true;
                pictureBox1.Visible = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        int flag = 0;
        int count = 0;
        List<PictureBox> poos1 = new List<PictureBox>();
        private void timer3_Tick(object sender, EventArgs e)
        {
            flag++;
            PictureBox poos = new PictureBox();
            poos.Image = Properties.Resources.poo;
            poos.Top = pictureBox4.Top;
            poos.Left = pictureBox4.Left;
            poos.Height = 42;
            poos.Width = 43;
            poos.SizeMode = PictureBoxSizeMode.StretchImage;
            poos.BringToFront();
            count++;
            this.Controls.Add(poos);
            poos1.Add(poos);

            for (int i = 0; i < poos1.Count; i++)
            {
                if (poos1[i].Enabled == true)
                {
                    lives--;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lives = 3;
            points = 0;
            timer1.Enabled = true;
            button2.Enabled = false;
            button2.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            label1.Enabled = false;
            label1.Visible = false;
            label2.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox6.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            button4.Enabled = false;
            button4.Visible = false;
            pictureBox4.Left = 573;
            pictureBox4.Top = 228;
            pictureBox6.Left = 12;
            pictureBox6.Top = 228;
            flag = 0;
            escape = 0;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            button1.Enabled = false;
            button1.Visible = false;
            button5.Enabled = false;
            button5.Visible = false;
            button6.Enabled = false;
            button6.Visible = false;
            button7.Enabled = true;
            button7.Visible = true;
            label14.Visible = true;
            label15.Visible = true;
            label16.Visible = true;
            label17.Visible = true;
            label18.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            button1.Enabled = false;
            button1.Visible = false;
            button5.Enabled = false;
            button5.Visible = false;
            button6.Enabled = false;
            button6.Visible = false;
            button7.Enabled = true;
            button7.Visible = true;
            label11.Visible = true;
            label12.Visible = true;
            label13.Visible = true;
            label19.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            button1.Enabled = true;
            button1.Visible = true;
            button5.Enabled = true;
            button5.Visible = true;
            button6.Enabled = true;
            button6.Visible = true;
            button7.Enabled = false;
            button7.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label16.Visible = false;
            label17.Visible = false;
            label18.Visible = false;
            label19.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label3.Visible = false;
            label1.Enabled = true;
            label1.Visible = true;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            label2.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            button1.Enabled = true;
            button1.Visible = true;
            button2.Enabled = false;
            button2.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            button5.Enabled = true;
            button5.Visible = true;
            button6.Enabled = true;
            button6.Visible = true;
            timer1.Enabled = false;
            timer2.Enabled = false;
            timer3.Enabled = false;
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            label3.Visible = false;
            label1.Enabled = true;
            label1.Visible = true;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            label2.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            button1.Enabled = true;
            button1.Visible = true;
            button2.Enabled = false;
            button2.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            button5.Enabled = true;
            button5.Visible = true;
            button6.Enabled = true;
            button6.Visible = true;
            timer1.Enabled = false;
            timer2.Enabled = false;
            timer3.Enabled = false;
        }
    }
}
