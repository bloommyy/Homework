﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int points = 0;
        int lives = 3;
        Random rnd = new Random();
        int numMove, numPlay;
        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button1.Visible = false;
            button2.Enabled = false;
            button3.Enabled = false;
            label1.Enabled = false;
            label1.Visible = false;
            label2.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label5.Text = points.ToString();
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox6.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            button4.Enabled = false;
            numPlay = rnd.Next(5, 11);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            numMove = rnd.Next(8);
            /*if (numMove == 5 || numMove == 6 || numMove == 7)
            {
                pictureBox5.Top = pictureBox4.Top;
                pictureBox5.Left = pictureBox4.Left;
            }
            if (numMove == 1 || numMove == 2 || numMove == 3)
            {
                pictureBox4.Top = pictureBox5.Top;
                pictureBox4.Left = pictureBox5.Left;
            }*/
        }
        int speed = 15;
        private void timer2_Tick(object sender, EventArgs e)
        {
            label5.Text = points.ToString();
            if (numMove == 0)
            {
                pictureBox4.Top -= speed;
            }
            else if (numMove == 1)
            {
                /*pictureBox4.Visible = true;
                pictureBox4.Enabled = true;
                pictureBox5.Visible = false;
                pictureBox5.Enabled = false;*/
                pictureBox4.Top -= speed;
                pictureBox4.Left += speed;
            }
            else if (numMove == 2)
            {
                /*pictureBox4.Visible = true;
                pictureBox4.Enabled = true;
                pictureBox5.Visible = false;
                pictureBox5.Enabled = false;*/
                pictureBox4.Left += speed;
            }
            else if (numMove == 3)
            {
                /*pictureBox4.Visible = true;
                pictureBox4.Enabled = true;
                pictureBox5.Visible = false;
                pictureBox5.Enabled = false;*/
                pictureBox4.Top += speed;
                pictureBox4.Left += speed;
            }
            else if (numMove == 4)
            {
                pictureBox4.Top += speed;
            }
            else if (numMove == 5)
            {
                /*pictureBox4.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox5.Visible = true;
                pictureBox5.Enabled = true;*/
                pictureBox4.Top += speed;
                pictureBox4.Left -= speed;
            }
            else if (numMove == 6)
            {
                /*pictureBox4.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox5.Visible = true;
                pictureBox5.Enabled = true;*/
                pictureBox4.Left -= speed;
            }
            else
            {
                /*pictureBox4.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox5.Visible = true;
                pictureBox5.Enabled = true;*/
                pictureBox4.Top -= speed;
                pictureBox4.Left -= speed;
            }

            if (pictureBox4.Top < -10)
            {
                pictureBox4.Top = -10;
            }
            if (pictureBox4.Top > 500)
            {
                pictureBox4.Top = 499;
            }

            if (pictureBox4.Left < -28)
            {
                pictureBox4.Left = -28;
            }
            if (pictureBox4.Left > 1151)
            {
                pictureBox4.Left = 1151;
            }

            if (pictureBox5.Top < -10)
            {
                pictureBox5.Top = -10;
            }
            if (pictureBox5.Top > 500)
            {
                pictureBox5.Top = 499;
            }

            if (pictureBox5.Left < -28)
            {
                pictureBox5.Left = -28;
            }
            if (pictureBox5.Left > 1151)
            {
                pictureBox5.Left = 1151;
            }
            if (lives == 0)
            {
                label6.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                label2.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                button3.Enabled = true;
                button3.Visible = true;
                label7.Visible = true;
                label8.Text = points.ToString();
                label8.Visible = true;
                label9.Visible = true;
                pictureBox7.Enabled = false;
                pictureBox7.Visible = false;
                button4.Enabled = true;
                button4.Visible = true;
                label4.Visible = false;
                label5.Visible = false;
            }
            if (points == 10)
            {
                label10.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                label2.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                button3.Enabled = true;
                button3.Visible = true;
                label7.Visible = true;
                label8.Text = points.ToString();
                label8.Visible = true;
                label9.Visible = true;
                pictureBox7.Enabled = false;
                pictureBox7.Visible = false;
                button4.Enabled = true;
                button4.Visible = true;
                label4.Visible = false;
                label5.Visible = false;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
            }
        }
        int escape = 0;
        private void From1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                pictureBox6.Left += speed;
            }
            if (e.KeyCode == Keys.Left)
            {
                pictureBox6.Left -= speed;
            }
            if (e.KeyCode == Keys.Up)
            {
                pictureBox6.Top -= speed;
            }
            if (e.KeyCode == Keys.Down)
            {
                pictureBox6.Top += speed;
            }

            if (pictureBox6.Top < 0)
            {
                pictureBox6.Top = 0;
            }
            if (pictureBox6.Top > 457)
            {
                pictureBox6.Top = 457;
            }

            if (pictureBox6.Left < 0)
            {
                pictureBox6.Left = 0;
            }
            if (pictureBox6.Left > 1221)
            {
                pictureBox6.Left = 1221;
            }
            if (e.KeyCode == Keys.Escape)
            {
                pictureBox1.Enabled = false;
                pictureBox1.Visible = false;
                pictureBox2.Enabled = false;
                pictureBox2.Visible = false;
                pictureBox3.Enabled = false;
                pictureBox3.Visible = false;
                pictureBox4.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox5.Enabled = false;
                pictureBox5.Visible = false;
                pictureBox6.Enabled = false;
                pictureBox6.Visible = false;
                label2.Visible = false;
                timer1.Enabled = false;
                timer2.Enabled = false;
                button2.Visible = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button3.Visible = true;
                label3.Visible = true;
                if (escape % 2 != 0)
                {
                    pictureBox1.Enabled = true;
                    pictureBox1.Visible = true;
                    pictureBox2.Enabled = true;
                    pictureBox2.Visible = true;
                    pictureBox3.Enabled = true;
                    pictureBox3.Visible = true;
                    pictureBox4.Enabled = true;
                    pictureBox4.Visible = true;
                    /*pictureBox5.Enabled = true;
                    pictureBox5.Visible = true;*/
                    pictureBox6.Enabled = true;
                    pictureBox6.Visible = true;
                    label2.Visible = true;
                    timer1.Enabled = true;
                    timer2.Enabled = true;
                    button2.Visible = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button3.Visible = false;
                    label3.Visible = false;
                }
                escape++;
            }

            if ((pictureBox6.Left - 83 <= pictureBox7.Left && pictureBox6.Left + 83 >= pictureBox7.Left) && (pictureBox6.Top <= pictureBox7.Top && pictureBox6.Top + 153 >= pictureBox7.Top))
                {
                    if (e.KeyCode == Keys.Space)
                    {
                        pictureBox7.Enabled = false;
                        pictureBox7.Visible = false;
                        points += 10;
                    }
                }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            pictureBox1.Visible = true;
            pictureBox2.Enabled = true;
            pictureBox2.Visible = true;
            pictureBox3.Enabled = true;
            pictureBox3.Visible = true;
            pictureBox4.Enabled = true;
            pictureBox4.Visible = true;
            /*pictureBox5.Enabled = true;
            pictureBox5.Visible = true;*/
            pictureBox6.Enabled = true;
            pictureBox6.Visible = true;
            label2.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            button2.Visible = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button3.Visible = false;
            label3.Visible = false;
            escape++;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }
        int flag = 0;
        private void timer3_Tick(object sender, EventArgs e)
        {
            flag++;
            if (flag == 1)
            {
                pictureBox7.Left = pictureBox4.Left + 30;
                pictureBox7.Top = pictureBox4.Top + 30;
                pictureBox7.Visible = true;
                pictureBox7.BringToFront();
            }
            if (flag == 2 && pictureBox7.Visible == true)
            {
                pictureBox3.Enabled = false;
                pictureBox3.Visible = false;
                lives--;
            }
            if (flag == 3 && pictureBox7.Visible == true)
            {
                pictureBox2.Enabled = false;
                pictureBox2.Visible = false;
                lives--;
            }
            if (flag == 4 && pictureBox7.Visible == true)
            {
                pictureBox1.Enabled = false;
                pictureBox1.Visible = false;
                lives--;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lives = 3;
            points = 0;
            timer1.Enabled = true;
            button2.Enabled = false;
            button2.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            label1.Enabled = false;
            label1.Visible = false;
            label2.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox6.Visible = true;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            button4.Enabled = false;
            button4.Visible = false;
            pictureBox4.Left = 573;
            pictureBox4.Top = 228;
            pictureBox6.Left = 12;
            pictureBox6.Top = 228;
            flag = 0;
            escape = 0;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
        }
    }
}
